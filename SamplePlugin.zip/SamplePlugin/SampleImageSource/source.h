#pragma once
#include "../splitcam_plugin.h"
#include <string>
#include <vector>

class Source
	: public splitcam::plugin::ISource
	, public splitcam::plugin::IImageSource
{
	CRITICAL_SECTION m_sec;
	SIZE m_Size;
	uint8_t* m_pImageBuffer;
	splitcam::plugin::IImageSource::DataCallback m_pDataCallback;
	void* m_pCallbackParam;

	HANDLE m_hThread;
	HANDLE m_hStop;

	static DWORD WINAPI ImageThread(void* pParam);

	struct SourceState
	{
		std::wstring id;
		bool paused;
	};

	using SOURCES = std::vector<SourceState>;
	SOURCES m_Sources;

public:
	Source();
	~Source();

	GUID image_iid() const;
	virtual GUID iid() const override;
	virtual const wchar_t* getName() const override;
	virtual void getSize(size_t&, size_t&) const override;
	virtual splitcam::plugin::ImageFormat getFormat() const override;
	virtual void setDataCallback(DataCallback, void*) override;
	virtual void setCanvasSize(size_t, size_t) override;
	virtual void open(const wchar_t*) override;
	virtual void close(const wchar_t*) override;
	virtual void pause(const wchar_t*, bool val) override;
};

extern Source g_Source;
