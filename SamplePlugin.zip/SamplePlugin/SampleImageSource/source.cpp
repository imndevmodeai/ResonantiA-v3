#include "pch.h"
#include "source.h"
#include <time.h>

Source g_Source;

Source::Source()
	: m_Size{ 1280, 720 }
	, m_pImageBuffer(nullptr)
	, m_pDataCallback(nullptr)
	, m_pCallbackParam(nullptr)
	, m_hThread(nullptr)
	, m_hStop(nullptr)
{
	InitializeCriticalSection(&m_sec);
	m_pImageBuffer = new uint8_t[m_Size.cx * m_Size.cy * 4];
	memset(m_pImageBuffer, 0, m_Size.cx* m_Size.cy * 4);
	m_hStop = CreateEvent(nullptr, TRUE, FALSE, nullptr);
}

Source::~Source()
{
	EnterCriticalSection(&m_sec);
	m_Sources.clear();
	close(nullptr);
	LeaveCriticalSection(&m_sec);

	if (m_hStop != nullptr)
	{
		CloseHandle(m_hStop);
		m_hStop = nullptr;
	}

	delete[] m_pImageBuffer;
	m_pImageBuffer = nullptr;

	DeleteCriticalSection(&m_sec);
}

GUID Source::iid() const
{
	return splitcam::plugin::ISource_v1;
}

GUID Source::image_iid() const
{
	return splitcam::plugin::IImageSource_v1;
}

const wchar_t* Source::getName() const
{
	return L"Sample Image Source";
}

void Source::getSize(size_t& width, size_t& height) const
{
	width = m_Size.cx;
	height = m_Size.cy;
}

splitcam::plugin::ImageFormat Source::getFormat() const
{
	return splitcam::plugin::ImageFormat::imageRGBA;
}

void Source::setDataCallback(DataCallback cb, void* param)
{
	m_pDataCallback = cb;
	m_pCallbackParam = param;
}

void Source::setCanvasSize(size_t width, size_t height)
{
}

void Source::open(const wchar_t* srcId)
{
	if (srcId == nullptr)
	{
		return;
	}

	EnterCriticalSection(&m_sec);

	SOURCES::const_iterator it = std::find_if(m_Sources.begin(), m_Sources.end(),
		[srcId](const SourceState& ss) { return wcscmp(ss.id.c_str(), srcId) == 0; });

	if (it == m_Sources.end())
	{
		m_Sources.push_back({srcId, false});
	}

	LeaveCriticalSection(&m_sec);

	if (m_hThread == nullptr)
	{
		ResetEvent(m_hStop);

		m_hThread = CreateThread(nullptr, 0, ImageThread, this, 0, nullptr);
	}
}

void Source::close(const wchar_t* srcId)
{
	if (srcId != nullptr)
	{
		EnterCriticalSection(&m_sec);

		SOURCES::const_iterator it = std::find_if(m_Sources.begin(), m_Sources.end(),
			[srcId](const SourceState& ss) { return wcscmp(ss.id.c_str(), srcId) == 0; });

		if (it != m_Sources.end())
		{
			m_Sources.erase(it);
		}

		LeaveCriticalSection(&m_sec);
	}

	if (m_Sources.size() == 0 && m_hThread != nullptr)
	{
		SetEvent(m_hStop);
		if (WaitForSingleObject(m_hThread, 3000) == WAIT_TIMEOUT)
		{
			TerminateThread(m_hThread, -1);
		}

		CloseHandle(m_hThread);
		m_hThread = nullptr;
	}
}

void Source::pause(const wchar_t* srcId, bool val)
{
	if (srcId != nullptr)
	{
		EnterCriticalSection(&m_sec);

		SOURCES::iterator it = std::find_if(m_Sources.begin(), m_Sources.end(),
			[srcId](const SourceState& ss) { return wcscmp(ss.id.c_str(), srcId) == 0; });

		if (it != m_Sources.end())
		{
			it->paused = val;
		}

		LeaveCriticalSection(&m_sec);
	}
}

DWORD WINAPI Source::ImageThread(void* pParam)
{
	Source* pThis = static_cast<Source*>(pParam);

	struct Position
	{
		int x;
		int y;
		int w;
		int h;
	} pos{ 0, 0, pThis->m_Size.cx / 6, pThis->m_Size.cx / 6 };

	srand((unsigned)time(nullptr));
	pos.x = rand() % (pThis->m_Size.cx - pos.w);
	pos.y = rand() % (pThis->m_Size.cy - pos.h);
	int xspeed = 1 + rand() % 11;
	int yspeed = 1 + rand() % 11;

	uint32_t bg = 0xc00d47a1;
	size_t len = pThis->m_Size.cx * pThis->m_Size.cy;

	while (WaitForSingleObject(pThis->m_hStop, 33) == WAIT_TIMEOUT)
	{
		if (pThis->m_pDataCallback == nullptr)
		{
			continue;
		}

		// we change background color every time we bounce from any edge
		bool bChangeBg = false;

		// bounce from left/right edges
		if ((pos.x + pos.w + xspeed) > pThis->m_Size.cx)
		{
			pos.x = pThis->m_Size.cx - pos.w;
			xspeed = -xspeed;
			bChangeBg = true;
		}
		else if ((pos.x + xspeed) < 0)
		{
			pos.x = 0;
			xspeed = -xspeed;
			bChangeBg = true;
		}
		else
		{
			pos.x += xspeed;
		}

		// bounce from top/bottom edges
		if ((pos.y + pos.h + yspeed) > pThis->m_Size.cy)
		{
			pos.y = pThis->m_Size.cy - pos.h;
			yspeed = -yspeed;
			bChangeBg = true;
		}
		else if ((pos.y + yspeed) < 0)
		{
			pos.y = 0;
			yspeed = -yspeed;
			bChangeBg = true;
		}
		else
		{
			pos.y += yspeed;
		}

		// change background if required
		if (bChangeBg)
		{
			uint8_t* pb = (uint8_t*)&bg;
			pb[0] = rand() % 256;
			pb[1] = rand() % 256;
			pb[2] = rand() % 256;
		}

		// clear the background
		for (size_t n = 0; n < len; ++n)
		{
			((uint32_t*)pThis->m_pImageBuffer)[n] = bg;
		}

		// draw transparent rectangle
		uint32_t* pPixels = (uint32_t*)pThis->m_pImageBuffer;
		for (int i = 0; i < pos.w; ++i)
		{
			for (int j = 0; j < pos.h; ++j)
			{
				uint32_t* pPixel = pPixels + ((pos.y + j) * pThis->m_Size.cx) + (pos.x + i);
				*pPixel = 0x00000000;
			}
		}

		// call splitcam callback function passing prepared image buffer and required parameters
		for (const auto& src : pThis->m_Sources)
		{
			if (!src.paused)
			{
				pThis->m_pDataCallback(
					src.id.c_str(), 
					splitcam::plugin::ImageFormat::imageRGBA, 
					pThis->m_pImageBuffer, 
					pThis->m_Size.cx, pThis->m_Size.cy, 
					pThis->m_pCallbackParam);
			}
		}
	}

	return 0;
}
