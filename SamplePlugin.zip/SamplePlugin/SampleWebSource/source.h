#pragma once
#include "../splitcam_plugin.h"
#include <string>
#include <vector>

class Source
	: public splitcam::plugin::ISource
	, public splitcam::plugin::IWebSource
{
	SIZE m_Size;

public:
	Source();
	~Source();

	GUID web_iid() const;
	virtual GUID iid() const override;
	virtual const wchar_t* getName() const override;
	virtual const wchar_t* getUrl() const override;
	virtual void getSize(size_t&, size_t&) const override;
	virtual void setCanvasSize(size_t, size_t) override;
	virtual void open(const wchar_t*) override;
	virtual void close(const wchar_t*) override;
	virtual void pause(const wchar_t*, bool val) override;
};

extern Source g_Source;
