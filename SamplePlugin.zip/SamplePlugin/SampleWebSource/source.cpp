#include "pch.h"
#include "source.h"

Source g_Source;

Source::Source()
	: m_Size{ 1280, 720 }
{
}

Source::~Source()
{
}

GUID Source::iid() const
{
	return splitcam::plugin::ISource_v1;
}

GUID Source::web_iid() const
{
	return splitcam::plugin::IWebSource_v1;
}

const wchar_t* Source::getName() const
{
	return L"Sample Web Source";
}

const wchar_t* Source::getUrl() const
{
	return L"https://splitcam.com/plugins/websample.html";
}

void Source::getSize(size_t& width, size_t& height) const
{
	width = m_Size.cx;
	height = m_Size.cy;
}

void Source::setCanvasSize(size_t width, size_t height)
{
}

void Source::open(const wchar_t* srcId)
{
}

void Source::close(const wchar_t* srcId)
{
}

void Source::pause(const wchar_t* srcId, bool val)
{
}
