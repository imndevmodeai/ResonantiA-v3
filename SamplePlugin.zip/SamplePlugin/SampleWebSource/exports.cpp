#include "pch.h"
#include "../splitcam_plugin.h"
#include "source.h"

namespace splitcam {
	namespace plugin {

		////////////////////////////////////////////////////////////////////////////////////
		// << exports >>
		// IPlugin

		const GUID getPluginInterfaceId()
		{
#pragma EXPORT

			return splitcam::plugin::IPlugin_v1;
		}

		const wchar_t* getPluginId()
		{
#pragma EXPORT

			return L"Web Sample SplitCam Plugin v1.0";
		}

		const wchar_t* getPluginName()
		{
#pragma EXPORT

			return L"Web Sample";
		}

		const wchar_t* getPluginProvider()
		{
#pragma EXPORT

			return L"SplitCam";
		}

		const splitcam::plugin::Version getPluginVersion()
		{
#pragma EXPORT

			return splitcam::plugin::Version{ 1, 0, 0 };
		}

		splitcam::plugin::PluginType getType()
		{
#pragma EXPORT

			return splitcam::plugin::PluginType::webSource;
		}

		bool init()
		{
#pragma EXPORT
			return true;
		}

		void release()
		{
#pragma EXPORT
		}


		////////////////////////////////////////////////////////////////////////////////////
		// << exports >>
		// ISource

		const GUID getSourceInterfaceId()
		{
#pragma EXPORT

			return g_Source.iid();
		}

		const wchar_t* getSourceName()
		{
#pragma EXPORT

			return g_Source.getName();
		}

		void getSourceSize(size_t& width, size_t& height)
		{
#pragma EXPORT

			g_Source.getSize(width, height);
		}

		void setCanvasSize(size_t, size_t)
		{
#pragma EXPORT
		}

		void openSource(const wchar_t* srcId)
		{
#pragma EXPORT

			g_Source.open(srcId);
		}

		void closeSource(const wchar_t* srcId)
		{
#pragma EXPORT

			g_Source.close(srcId);
		}

		void pauseSource(const wchar_t* srcId, bool val)
		{
#pragma EXPORT

			g_Source.pause(srcId, val);
		}


		////////////////////////////////////////////////////////////////////////////////////
		// << exports >>
		// IWebSource

		const GUID getWebInterfaceId()
		{
#pragma EXPORT

			return g_Source.web_iid();
		}

		const wchar_t* getUrl()
		{
#pragma EXPORT
			return g_Source.getUrl();
		}

		////////////////////////////////////////////////////////////////////////////////////
		// << exports >>
		// IEventHandler

		const GUID getEventsInterfaceId()
		{
#pragma EXPORT

			return splitcam::plugin::IEventHandler_v1;
		}

		void onLoad()
		{
#pragma EXPORT
		}

		void onUnload()
		{
#pragma EXPORT
		}
		void onCanvasSize(size_t, size_t)
		{
#pragma EXPORT
		}

		void onPosition(const wchar_t*, int, int, size_t, size_t)
		{
#pragma EXPORT
		}

	}
}